#coding=utf-
#引入模块和模块中的函数
from flask import Flask,render_template,request
import plotly.express as px
import pandas as pd
import numpy as np
from pyecharts import options as opts
from pyecharts.charts import Geo
from pyecharts.globals import ChartType, SymbolType
#from pyecharts import  SymbolType,ThemeType # .globals   ChartType,
# from pyecharts import Bar,Line,Map,Timeline,Page, Pie  #,Tab
# from prettytable import PrettyTable
# from pyecharts import Faker  #.faker
# from pyecharts import options as opts
# import tkinter as tk  # 使用Tkinter前需要先导入
# import tkinter.messagebox
import pickle
import csv



app = Flask(__name__)

#生成吸烟致癌症死亡率和癌症类型的两个图的后端代码
@app.route('/')
def hello_world():
      # f1.readlines()读取f1的数据，并且转化为字符串
    with open("html_photos/中国500强企业在各个城市招聘教育岗位的数量.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
        education_quality = "".join(f1.readlines())
    with open("html_photos/中国企业招聘教育岗位学历要求.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
        education_xueli = "".join(f1.readlines())
    with open("html_photos/中国企业招聘教育岗位经验要求.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
        education_jingyan = "".join(f1.readlines())
    with open("html_photos/猎聘网中国企业招聘教育岗位的语言要求.html", encoding="utf8",mode="r") as f1:  # 打开CSV文件，f1作为文件流
        education_language = "".join(f1.readlines())
    with open("html_photos/中国企业教育岗位任职要求主题建模.html", encoding="utf8",mode="r") as f1:  # 打开CSV文件，f1作为文件流
        education_jianmo= "".join(f1.readlines())
    with open("html_photos/中国500强企业招聘教育职位要求词云图.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
        education_ciyuntu= "".join(f1.readlines())
        return render_template("index.html",#后端代码渲染图到index.html前端页面
                               the_education_quality=education_quality,
                               the_education_xueli=education_xueli,
                               the_education_jingyan=education_jingyan,
                               the_education_language=education_language,
                               the_education_jianmo=education_jianmo,
                               the_education_ciyuntu=education_ciyuntu
                               #the_list=list_data
                               # bar_data=bar.dump_options(),#.dump_options()函数渲染图到前端页面，由bar_data变量在前端页面进行接收
                    # line_data=line.dump_options()#.dump_options()函数渲染图到前端页面，由line_data变量在前端页面进行接收

                                )





#渲染患病率的图到前端页面
# @app.route('/solution',methods=['POST'])
# def problem_solution() -> 'html':
#     with open("html_photos/中国500强企业在各个城市招聘数据分析岗位的数量.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         pandas_quality = "".join(f1.readlines())  # f1.readlines()读取f1的数据，并且转化为字符串
#         # interactive_controls = ['世界癌症死亡人数']  # 绑定前端页面的按钮以实现Python页面与前端页面交互
#         # park_title = '深圳市停车场分布气泡图'  # 网页标题
#     with open("html_photos/中国五百强企业招聘数据分析岗位学历要求.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         pandas_xueli = "".join(f1.readlines())  # f1.readlines()读取f1的数据，并且转化为字符串
#         # interactive_controls = ['世界癌症死亡人数']  # 绑定前端页面的按钮以实现Python页面与前端页面交互
#         # park_title_pao = '深圳市停车场分布散点地图'
#     with open("html_photos/中国500强企业招聘数据分析岗位经验要求.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         pandas_jingyan = "".join(f1.readlines())  # f1.readlines()读取f1的数据，并且转化为字符串
#         # interactive_controls = ['世界癌症死亡人数']  # 绑定前端页面的按钮以实现Python页面与前端页面交互
#         # hotel_point_title = '深圳酒店分布气泡图'
#     with open("html_photos/猎聘网中国五百强企业招聘数据分析岗位的语言要求.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         pandas_language = "".join(f1.readlines())  # f1.readlines()读取f1的数据，并且转化为字符串
#         # interactive_controls = ['世界癌症死亡人数']  # 绑定前端页面的按钮以实现Python页面与前端页面交互
#         # hotel_dot_title = '深圳市不同区域酒店气泡图'
#     with open("html_photos/中国500强企业数据分析岗位任职要求主题建模.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         pandas_jianmo = "".join(f1.readlines())
#     with open("html_photos/中国500强企业招聘数据分析岗位职位要求词云图.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         pandas_ciyuntu = "".join(f1.readlines())
#         return render_template('results2.html', #向/world_hbl返回result.html页面
#                             #the_plot_all_1 = plot_all_1,#赋值给变量以渲染图表到前端页面
#                             the_pandas_quality=pandas_quality,
#                             the_pandas_xueli=pandas_xueli,
#                             the_pandas_jingyan=pandas_jingyan,
#                             the_pandas_language=pandas_language,
#                             the_pandas_jianmo=pandas_jianmo,
#                             the_pandas_ciyuntu=pandas_ciyuntu
#                             #the_title = title,#赋值给变量以渲染标题到前端页面
#                             # the_list = list_data,#渲染列表到前端
#                             )
#
# @app.route('/addition',methods=['POST'])
# def world_death_person() -> 'html':
#     with open("html_photos/中国500强企业在各个城市招聘用户体验岗位的数量.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         user_quality = "".join(f1.readlines())
#     with open("html_photos/中国五百强企业招聘用户体验岗位学历要求.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         user_xueli = "".join(f1.readlines())  # f1.readlines()读取f1的数据，并且转化为字符串
#         # interactive_controls = ['世界癌症死亡人数']  # 绑定前端页面的按钮以实现Python页面与前端页面交互
#         # park_title_pao = '深圳市停车场分布散点地图'
#     with open("html_photos/中国500强企业招聘用户体验岗位经验要求.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         user_jingyan = "".join(f1.readlines())  # f1.readlines()读取f1的数据，并且转化为字符串
#         # interactive_controls = ['世界癌症死亡人数']  # 绑定前端页面的按钮以实现Python页面与前端页面交互
#         # hotel_point_title = '深圳酒店分布气泡图'
#     with open("html_photos/猎聘网中国五百强企业招聘用户体验岗位的语言要求.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         user_language = "".join(f1.readlines())  # f1.readlines()读取f1的数据，并且转化为字符串
#         # interactive_controls = ['世界癌症死亡人数']  # 绑定前端页面的按钮以实现Python页面与前端页面交互
#         # hotel_dot_title = '深圳市不同区域酒店气泡图'
#     with open("html_photos/中国500强企业用户体验相关岗位任职要求主题建模.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         user_jianmo = "".join(f1.readlines())
#     with open("html_photos/中国500强企业招聘用户体验岗位职位要求词云图.html", encoding="utf8", mode="r") as f1:  # 打开CSV文件，f1作为文件流
#         user_ciyuntu = "".join(f1.readlines())
#         return render_template('field.html',     #向/world_death_person返回result2.html页面
#                                the_user_quality=user_quality,
#                                the_user_xueli=user_xueli,
#                                the_user_jingyan=user_jingyan,
#                                the_user_language=user_language,
#                                the_user_jianmo=user_jianmo,
#                                the_user_ciyuntu=user_ciyuntu
#                            )
#


if __name__ == '__main__':
    app.run(debug=True)